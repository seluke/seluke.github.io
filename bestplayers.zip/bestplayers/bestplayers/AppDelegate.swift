//
//  AppDelegate.swift
//  bestplayers
//
//  Created by Luke Ahn on 12/11/2018.
//  Copyright © 2018 se-luke. All rights reserved.
//

import UIKit
import Branch
import AdSupport

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {

        //Branch.setUseTestBranchKey(true)
        if let branch = Branch.getInstance() {
            //branch.setDebug()
            
            /*
            Branch.getInstance().loadRewards { (changed, error) in
                // option 1 (defualt bucket)
                let credits = Branch.getInstance().getCredits()
                print("Branch-Luke-Point:\(credits)")
                
            }
            
            Branch.getInstance().getCreditHistory { (creditHistory, error) in
                print(creditHistory ?? {})
            }
            */
            
            
            //Branch: in-app deep link routing option1
            branch.initSession(launchOptions: launchOptions, andRegisterDeepLinkHandler: {params, error in
                print("Branch SDK - initSession CALL")
                if error == nil {
                    
                    let idfa = ASIdentifierManager.shared().advertisingIdentifier.uuidString
                    print("LUKE-ADID", idfa, separator:": ")
                    
                    /*Used for print campaign, deeplink_path, tags, channel when debugMode is disabled.
                        Sometimes NSURLSession+Branch can not logs the response of first session*/
                    if let p = params {
                        if let campaign = p["~campaign"] {
                            print("SESSION-CAMPAIGN", campaign, separator:": ")
                        } else {
                            print("SESSION-CAMPAIGN", "nil", separator:": ")
                        }
                        
                        if let deeplink_path = p["$deeplink_path"] {
                            print("SESSION-DEEPLINKPATH", deeplink_path, separator:": ")
                        } else {
                            print("SESSION-DEEPLINKPATH", "nil", separator:": ")
                        }
                        
                        if let tags = p["~tags"] {
                            print("SESSION-TAGS", tags, separator:": ")
                        } else {
                            print("SESSION-TAGS", "nil", separator:": ")
                        }
                        
                        if let channel = p["~channel"] {
                            print("SESSION-CHANNEL", channel, separator:": ")
                        } else {
                            print("SESSION-CHANNEL", "nil", separator:": ")
                        }

                    }
                    
                    if let p = params, let index = p["player_index"] as! String?, p["+clicked_branch_link"] != nil  {
                        let player = PlayersStore.getInstance().getPlayerWithIndex(index: Int(index)!)
                        let storyboard = UIStoryboard(name: "Main", bundle: nil)
                        let playerDetailViewController = storyboard.instantiateViewController(withIdentifier: "player_detail_story") as! PlayerDetailViewController
                        playerDetailViewController.player = player
                        
                        let playersNavigationViewController = storyboard.instantiateViewController(withIdentifier: "players_navigation") as! PlayersNavigationViewController
                        
                        playersNavigationViewController.pushViewController(playerDetailViewController, animated:true)
                        self.window?.rootViewController?.present(playersNavigationViewController, animated: true, completion: nil)
    
                    }
                } else {
                    
                }
                
                
            })
 
            /*
            //Branch: in-app deep link routing option3
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let playersNavigationViewController = storyboard.instantiateViewController(withIdentifier: "players_navigation") as! PlayersNavigationViewController
            branch.registerDeepLinkController(playersNavigationViewController, forKey: "player_index", withPresentation: .optionShow)
            branch.initSession(launchOptions: launchOptions, automaticallyDisplayDeepLinkController: true)
            */
        }
        print("Branch-Luke: initSession called")
        return true
    }
    
    func application(_ app: UIApplication, open url: URL, options: [UIApplicationOpenURLOptionsKey : Any] = [:]) -> Bool {
        print("LUKE - openURL CALL")
        Branch.getInstance()?.application(app, open: url, options: options)

        return true
    }
    
    func application(_ application: UIApplication, continue userActivity: NSUserActivity, restorationHandler: @escaping ([Any]?) -> Void) -> Bool {
        Branch.getInstance()?.continue(userActivity)
        return true
    }

    func applicationWillResignActive(_ application: UIApplication) {
      
    }

    func applicationDidEnterBackground(_ application: UIApplication) {

    }

    func applicationWillEnterForeground(_ application: UIApplication) {
       
    }

    func applicationDidBecomeActive(_ application: UIApplication) {
      
    }

    func applicationWillTerminate(_ application: UIApplication) {
        
    }
}
