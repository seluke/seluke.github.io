//
//  PlayersStore.swift
//  bestplayers
//
//  Created by Luke An on 11/27/18.
//  Copyright © 2018 se-luke. All rights reserved.
//

import UIKit

class PlayersStore {
    private var players:Array<Player>
    private static var sharedPlayersStore = {
       return PlayersStore.init()
    }()
    
    class func getInstance() -> PlayersStore {
        return self.sharedPlayersStore
    }
    
    private init() {
        self.players = [Player]()
        let ronaldoPhoto = UIImage(named: "cronaldo")
        let messiPhoto = UIImage(named: "messi")
        let neymarPhoto = UIImage(named: "neymar")
        
        
        guard let ronaldo = Player(name: "Cristiano Ronaldo", club: "Juventus", nation: "Portugal", photo: ronaldoPhoto, birthDate: "1985-02-05", height: 187, weight: 80, position: "Forward", index:0) else {
            fatalError("Unable to instantiate Ronaldo")
        }
        
        guard let messi = Player(name: "Lionel Andrés Messi ", club: "Barcelona", nation: "Argentina", photo: messiPhoto, birthDate: "1987-06-24", height: 170, weight: 67, position: "Forward", index:1) else {
            fatalError("Unable to instantiate Messi")
        }
        
        guard let neymar = Player(name: "Neymar", club: "Paris Saint-Germain", nation: "Brazil", photo: neymarPhoto, birthDate: "1992-02-05", height: 175, weight: 68, position: "Forward", index:2) else {
            fatalError("Unable to instantiate Neymar")
        }
        
        ronaldo.setImageURL(url: "https://cdn.calciomercato.com/images/2018-11/Ronaldo.Juve.esulta.Milan.356x237.jpg")
        messi.setImageURL(url: "https://maisfutebol.iol.pt/multimedia/oratvi/multimedia/imagem/id/5a91d8810cf248c46ec41365/960")
        neymar.setImageURL(url: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQpHNzUNTeKvIN6NaTqhOR5BXkjHv9TzgJY1p69kUSRDgahirDy")
        players += [ronaldo, messi, neymar]
    }
    
    func getPlayerWithIndex(index:Int) -> Player {
        return self.players[index]
    }
    
    func addPlayer(player:Player) -> Void {
        self.players += [player]
    }
    
    func getCount() -> Int {
        return self.players.count
    }
}
