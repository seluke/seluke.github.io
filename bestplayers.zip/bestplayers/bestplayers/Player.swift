//
//  Player.swift
//  bestplayers
//
//  Created by Luke Ahn on 22/11/2018.
//  Copyright © 2018 se-luke. All rights reserved.
//

import UIKit

class Player {
    private var name: String
    private var club: String
    private var nation: String
    private var photo: UIImage?
    private var birthDate: String
    private var height: Int
    private var weight: Int
    private var position: String
    private var index:Int?
    private var imageURL:String?
    
    init?(name:String, club: String, nation: String, photo: UIImage?, birthDate: String, height: Int, weight: Int, position: String, index:Int) {
        if name.isEmpty || nation.isEmpty || birthDate.isEmpty {
            return nil
        }
        
        self.name = name
        self.club = club
        self.nation = nation
        self.photo = photo
        self.birthDate = birthDate
        self.height = height
        self.weight = weight
        self.position = position
        self.index = index
    }
    
    init?(name:String, club: String, nation: String, photo: UIImage?, birthDate: String, height: Int, weight: Int, position: String) {
        if name.isEmpty || nation.isEmpty || birthDate.isEmpty {
            return nil
        }
        
        self.name = name
        self.club = club
        self.nation = nation
        self.photo = photo
        self.birthDate = birthDate
        self.height = height
        self.weight = weight
        self.position = position
    }
    
    func setName(name:String) -> Void {
        self.name = name
    }
    
    func getName() -> String {
        return self.name
    }
    
    func setClub(club:String) -> Void {
        self.club = club
    }
    
    func getClub() -> String {
        return self.club
    }
    
    func setNation(nation:String) -> Void {
        self.nation = nation
    }
    
    func getNation() -> String {
        return self.nation
    }
    
    func setPhoto(photo:UIImage) -> Void {
        self.photo = photo
    }
    
    func getPhoto() -> UIImage? {
        return self.photo
    }
    
    func setBirthDate(birthDate:String) -> Void {
        self.birthDate = birthDate
    }
    
    func getBirthDate() -> String {
        return self.birthDate
    }
    
    func setHeight(height:Int) -> Void {
        self.height = height
    }
    
    func getHeight() -> Int {
        return self.height
    }
    
    func setWeight(weight:Int) -> Void {
        self.weight = weight
    }
    
    func getWeight() -> Int {
        return self.weight
    }
    
    func setPosition(position:String) -> Void {
        self.position = position
    }
    
    func getPosition() -> String {
        return self.position
    }
    
    func setIndex(index:Int) -> Void {
        self.index = index
    }
    
    func getIndex() -> Int? {
        return self.index
    }
    
    func setImageURL(url:String) -> Void {
        self.imageURL = url
    }
    
    func getImageURL() -> String? {
        return self.imageURL
    }
}
