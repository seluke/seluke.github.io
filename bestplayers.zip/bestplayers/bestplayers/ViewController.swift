//
//  ViewController.swift
//  bestplayers
//
//  Created by Luke Ahn on 12/11/2018.
//  Copyright © 2018 se-luke. All rights reserved.
//

import UIKit
import Branch

class ViewController: UIViewController, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    //MARK: Properties
    @IBOutlet weak var userIDTextField: UITextField!
    @IBOutlet weak var passwordTextField: UITextField!
    @IBOutlet weak var mainPageImg: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        userIDTextField.delegate = self
        passwordTextField.delegate = self
        
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    

    //MARK: Actions
    @IBAction func clickRegisterButton(_ sender: UIButton) {
        /*
        let branchLink = "https://seluke.test-app.link/iZyYQJwegS"
        Branch.getInstance().handleDeepLink(withNewSession: URL(string: branchLink))
 */
        let item1 = BranchUniversalObject.init()
        item1.contentMetadata.productName = "애플 맥북 15인치 컴퓨터 터치바 버전 10%"
        item1.contentMetadata.productBrand = "애플"
        
        item1.contentMetadata.addressCountry = "미국"
        item1.contentMetadata.addressCity = "샌프란시스코"
        
        let item2 = BranchUniversalObject.init()
        item2.contentMetadata.productName = "2019년 설날 휴가 100% 좋아"
        item2.contentMetadata.productBrand = "많이 쉬는 명절 $10000"
        
        item2.contentMetadata.addressCountry = "한국"
        item2.contentMetadata.addressCity = "서울"
        
        let event = BranchEvent.standardEvent(.addToWishlist)
        event.contentItems = [item1, item2]
        event.searchQuery = "희망사항들"
        event.coupon = "기분 좋은 쿠폰"
        event.logEvent()
    }
    
    
    @IBAction func clickSignUpButton(_ sender: UIButton) {
        if let uid = userIDTextField.text, let pw = passwordTextField.text {
            if uid == "luke" && pw == "luke" {
                
                //Branch: track login event
                //BranchEvent.customEvent(withName: "login").logEvent()
                
                let buo = BranchUniversalObject.init()
                buo.contentMetadata.sku = "a123"
                buo.contentMetadata.price = 10
                buo.contentMetadata.quantity = 3
                buo.contentMetadata.currency = BNCCurrency.USD
                
                
                let sEvent = BranchEvent.customEvent(withName: "Remove from Cart")
                sEvent.searchQuery = "search address"
                sEvent.transactionID = "trans 123"
                sEvent.contentItems = [buo]
                sEvent.currency = BNCCurrency.USD
                sEvent.revenue = 26
                sEvent.logEvent()
                
                
                
                
                
                
                let storyboard = UIStoryboard(name: "Main", bundle: nil)
                let playerTableViewController = storyboard.instantiateViewController(withIdentifier: "players_navigation")
                self.present(playerTableViewController, animated: true, completion: nil)
            } else {
                let alertController:UIAlertController = UIAlertController(title: "Warning!", message: "Please check User ID and password", preferredStyle: .alert)
                alertController.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
                    NSLog("The \"OK\" alert occured.")
                }))
                self.present(alertController, animated: true, completion: nil)
            }
        } else {
            
            let alertController:UIAlertController = UIAlertController(title: "Warning!", message: "Please enter User ID and password", preferredStyle: .alert)
             alertController.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
             NSLog("The \"OK\" alert occured.")
             }))
            self.present(alertController, animated: true, completion: nil)
    }
    }
    @IBAction func selectImgFromPhotoLibrary(_ sender: UITapGestureRecognizer) {
        userIDTextField.resignFirstResponder()
        passwordTextField.resignFirstResponder()
        let imagePickerController = UIImagePickerController()
        imagePickerController.sourceType = .photoLibrary
        imagePickerController.delegate = self
        present(imagePickerController, animated: true, completion: nil)
        
    }
    //MARK: UITextFieldDelegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        
    }
    
    //MARK: UIImagePickerControllerDelegate
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        guard let selectedImage = info[UIImagePickerControllerOriginalImage] as? UIImage else {
            fatalError("Expected a dictionary containing an image, but was provided the following: \(info)")
        }
        mainPageImg.image = selectedImage
        
        //Branch: Track change_mainpage_image event
        BranchEvent.customEvent(withName: "change_mainpage_image")
        
        dismiss(animated: true, completion: nil)
    }
}


