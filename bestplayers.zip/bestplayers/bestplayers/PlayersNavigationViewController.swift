//
//  PlayersNavigationViewController.swift
//  bestplayers
//
//  Created by Luke An on 11/29/18.
//  Copyright © 2018 se-luke. All rights reserved.
//

import UIKit
import Branch

/*
 Branch: In order to implement in-app deeplink routing via option 3 of following docs,
 you should register BranchDeepLinkingController protocal
 https://docs.branch.io/pages/deep-linking/routing/
 You also add var deepLinkingCompletionDelegate: BranchDeepLinkingControllerCompletionDelegate?// as member of this class
 You should override two method from BranchDeepLinkingController.
 configureControl(withData params: [AnyHashable: Any]!)
 closePressed()
 */
class PlayersNavigationViewController: UINavigationController, BranchDeepLinkingController {
    
    var deepLinkingCompletionDelegate: BranchDeepLinkingControllerCompletionDelegate?//for in-app deeplink routing option 3
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    //overrided from BranchDeepLinkingController
    //in order to build option 3 for in-app deeplink routing
    func configureControl(withData params: [AnyHashable: Any]!) {
        let dict = params as Dictionary
        if let index = dict["player_index"] as! String? {
            let player = PlayersStore.getInstance().getPlayerWithIndex(index: Int(index)!)
            let storyboard = UIStoryboard(name: "Main", bundle: nil)
            let playerDetailViewController = storyboard.instantiateViewController(withIdentifier: "player_detail_story") as! PlayerDetailViewController
            playerDetailViewController.player = player
            self.pushViewController(playerDetailViewController, animated:true)
        }
    }
    //overrided from BranchDeepLinkingController
    //in order to build option 3 for in-app deeplink routing
    func closePressed() {
        self.deepLinkingCompletionDelegate!.deepLinkingControllerCompleted()
    }

}
