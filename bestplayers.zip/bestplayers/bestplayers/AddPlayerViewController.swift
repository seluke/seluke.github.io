//
//  AddPlayerViewController.swift
//  bestplayers
//
//  Created by Luke An on 11/27/18.
//  Copyright © 2018 se-luke. All rights reserved.
//

import UIKit
import os.log

class AddPlayerViewController: UIViewController, UIImagePickerControllerDelegate, UINavigationControllerDelegate {
    @IBOutlet weak var playerPhoto: UIImageView!
    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var birthDateField: UITextField!
    @IBOutlet weak var heightField: UITextField!
    @IBOutlet weak var weightField: UITextField!
    @IBOutlet weak var positionField: UITextField!
    @IBOutlet weak var clubField: UITextField!
    @IBOutlet weak var nationField: UITextField!
    @IBOutlet weak var saveButton: UIBarButtonItem!
    var player:Player?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    

    
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        
        guard let button = sender as? UIBarButtonItem, button == saveButton else {
            os_log("The save button was not pressed", log:OSLog.default, type:.debug)
            return
        }
        
        guard let photo = self.playerPhoto.image else {
            self.alertWindow(message: "Please chose a photo")
            return
        }
        guard let name = self.nameField.text else {
            self.alertWindow(message: "Please enter player's name")
            return
        }
        guard let birthDate = self.birthDateField.text else {
            self.alertWindow(message: "Please enter player's birth day")
            return
        }
        guard let weightStr = self.weightField.text else {
            self.alertWindow(message: "Please enter player's weight")
            return
        }
        guard let heightStr = self.heightField.text else {
            self.alertWindow(message: "Please enter player's height")
            return
        }
        guard let position = self.positionField.text else {
            self.alertWindow(message: "Please enter player's position")
            return
        }
        guard let club = self.clubField.text else {
            self.alertWindow(message: "Please enter player's club")
            return
        }
        guard let nation = self.nationField.text else {
            self.alertWindow(message: "Please enter player's nationality")
            return
        }
        
        guard let height = Int(heightStr) else {
            self.alertWindow(message: "Height must be number")
            return
        }
        guard let weight = Int(weightStr) else {
            self.alertWindow(message: "Weight must be number")
            return
        }
        self.player = Player.init(name: name, club: club, nation: nation, photo: photo, birthDate: birthDate, height: height, weight: weight, position: position, index:PlayersStore.getInstance().getCount())
    }
    
    //MARK: Util
    func alertWindow(message:String) -> Void {
        let alertController:UIAlertController = UIAlertController(title: "Warning!", message: message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: NSLocalizedString("OK", comment: "Default action"), style: .default, handler: { _ in
            NSLog("The \"OK\" alert occured.")
        }))
        self.present(alertController, animated: true, completion: nil)
    }
    
    
    
    //MARK: UIImagePickerControllerDelegate
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        guard let selectedImage = info[UIImagePickerControllerOriginalImage] as? UIImage else {
            fatalError("Expected a dictionary containing an image, but was provided the following: \(info)")
        }
        self.playerPhoto.image = selectedImage
        dismiss(animated: true, completion: nil)
    }
    @IBAction func selectPhotoFromLibrary(_ sender: UITapGestureRecognizer) {
        let imagePickerController = UIImagePickerController()
        imagePickerController.sourceType = .photoLibrary
        imagePickerController.delegate = self
        self.present(imagePickerController, animated: true, completion: nil)
    }
    
    //MARK: Navigation
    @IBAction func cancel(_ sender: UIBarButtonItem) {
        dismiss(animated: true, completion: nil)
        
    }
    
}



