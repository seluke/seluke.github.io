//
//  PlayerDetailViewController.swift
//  bestplayers
//
//  Created by Luke An on 11/28/18.
//  Copyright © 2018 se-luke. All rights reserved.
//

import UIKit
import Branch


class PlayerDetailViewController: UIViewController {
    
    @IBOutlet weak var playerPhoto: UIImageView!
    @IBOutlet weak var nameField: UITextField!
    @IBOutlet weak var birthDateField: UITextField!
    @IBOutlet weak var heightField: UITextField!
    @IBOutlet weak var weightField: UITextField!
    @IBOutlet weak var positionField: UITextField!
    @IBOutlet weak var clubField: UITextField!
    @IBOutlet weak var nationField: UITextField!
    var player:Player!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        self.playerPhoto.image = player.getPhoto()
        self.nameField.text = player.getName()
        self.birthDateField.text = player.getBirthDate()
        self.heightField.text = "\(player.getHeight())"
        self.weightField.text = "\(player.getWeight())"
        self.positionField.text = player.getPosition()
        self.clubField.text = player.getClub()
        self.nationField.text = player.getNation()
        
        //Branch: Track player_detail_view event
        let customMeta = NSMutableDictionary.init()
        customMeta["birth_date"] = player.getBirthDate()
        customMeta["height"] = player.getHeight()
        customMeta["weight"] = player.getWeight()
        customMeta["position"] = player.getPosition()
        customMeta["club"] = player.getClub()
        customMeta["nation"] = player.getNation()
        
        let buo = BranchUniversalObject.init()
        buo.canonicalIdentifier = "sp-\(player.getName()))"
        buo.title = player.getName()
        buo.contentMetadata.customMetadata = customMeta
        
        let branchEvent = BranchEvent.customEvent(withName: "player_detail_view", contentItem: buo)
        branchEvent.logEvent()
    }
    
    //MARK: Action
    
    @IBAction func sharePlayer(_ sender: UIButton) {
        //Branch: Create content reference link and share it
        let buo = BranchUniversalObject.init(canonicalIdentifier:"pid-"+player.getName())
        buo.title = "Exciting Player: " + player.getName()
        buo.contentDescription = "Name: " + player.getName() + "\n" + "BirthDate: " + player.getBirthDate() + "\n" + "Club: " + player.getClub() + "\n"
        buo.imageUrl = player.getImageURL()
        buo.publiclyIndex = true
        buo.locallyIndex = true
        buo.contentMetadata.customMetadata["player_index"] = self.player.getIndex()
        
        //Branch SDK: Create link reference
        let lp: BranchLinkProperties = BranchLinkProperties()
        lp.feature = "sharing"
        lp.campaign = "Player test campaign"
        lp.stage = "new user"
        lp.tags = ["Player", "Soccer", "Star"]
        lp.addControlParam("$desktop_url", withValue: "http://branch.io")
        lp.addControlParam("$ios_url", withValue: "https://branch.io")
        lp.addControlParam("$android_url", withValue: "https://branch.io")
        lp.addControlParam("$match_duration", withValue: "2000")
        lp.addControlParam("$deeplink_path", withValue: "playerdetail")
        lp.addControlParam("player_index", withValue: String(player.getIndex()!))

        //Branch SDK: Share Deep Link
        let message = "Check out this link"
        buo.showShareSheet(with: lp, andShareText: message, from: self, completion: nil)
    }
}
