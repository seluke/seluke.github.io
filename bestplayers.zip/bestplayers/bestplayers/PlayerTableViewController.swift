//
//  PlayerTableViewController.swift
//  bestplayers
//
//  Created by Luke Ahn on 22/11/2018.
//  Copyright © 2018 se-luke. All rights reserved.
//

import UIKit
import Branch

class PlayerTableViewController: UITableViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        //Branch: Track player_list_ivew event
        let branchEvent = BranchEvent.customEvent(withName: "player_list_view")
        branchEvent.logEvent()
    }

    // MARK: - Table view data source

    override func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return PlayersStore.getInstance().getCount()
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cellIdentifier = "PlayerTableViewCell"
        guard let cell = tableView.dequeueReusableCell(withIdentifier: cellIdentifier, for: indexPath) as? PlayerTableViewCell else{
            fatalError("The dequeued cell is not an instance of PlayerTableVeiwCell")
        }
 
        let player = PlayersStore.getInstance().getPlayerWithIndex(index: indexPath.row)
        
        cell.playerPhotoField.image = player.getPhoto()
        cell.playerNameField.text = player.getName()
        cell.clubNameField.text = player.getClub()
        cell.nationNameField.text = player.getNation()

        return cell
    }
    
    //MARK: Actions
    @IBAction func unwindToPlayerList(sender:UIStoryboardSegue) {
        if let sourceViewController = sender.source as? AddPlayerViewController, let player = sourceViewController.player {
            let newIndexPath = IndexPath(row: PlayersStore.getInstance().getCount(), section: 0)
            PlayersStore.getInstance().addPlayer(player: player)
            self.tableView.insertRows(at:[newIndexPath], with: .automatic)
            
            //Branch: Track add_player event
            let customMeta = NSMutableDictionary.init()
            customMeta["birth_date"] = player.getBirthDate()
            customMeta["height"] = player.getHeight()
            customMeta["weight"] = player.getWeight()
            customMeta["position"] = player.getPosition()
            customMeta["club"] = player.getClub()
            customMeta["nation"] = player.getNation()
            
            let buo = BranchUniversalObject.init()
            buo.canonicalIdentifier = "sp-\(player.getName()))"
            buo.title = player.getName()
            buo.contentMetadata.customMetadata = customMeta
            
            let branchEvent = BranchEvent.customEvent(withName: "add_player", contentItem: buo)
            branchEvent.logEvent()
        }
    }
    
    // MARK: - Navigation
    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "player_detail_segue" {
            if let row = tableView.indexPathForSelectedRow?.row {
                let player = PlayersStore.getInstance().getPlayerWithIndex(index: row)
                let playerDetailViewController = segue.destination as! PlayerDetailViewController
                playerDetailViewController.player = player
            }
        }
    }
}
