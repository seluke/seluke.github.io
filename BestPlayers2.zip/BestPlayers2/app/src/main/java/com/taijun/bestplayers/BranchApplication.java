package com.taijun.bestplayers;

import android.app.Application;
import android.content.Intent;
import android.util.Log;

import io.branch.referral.Branch;

public class BranchApplication extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        Log.i("Branch-SDK", "Application Class onCreate");
        //Branch.enableLogging();
        Branch.getAutoInstance(this);
    }
}
