package com.taijun.bestplayers;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;

import io.branch.indexing.BranchUniversalObject;
import io.branch.referral.Branch;
import io.branch.referral.util.BRANCH_STANDARD_EVENT;
import io.branch.referral.util.BranchEvent;
import io.branch.referral.util.ContentMetadata;
import io.branch.referral.util.CurrencyType;

public class PlayerDetailActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_player_detail);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

        final Intent intent = new Intent(this, MainActivity.class);
        intent.putExtra("branch", "https://seluke.test-app.link/WL57OIy7fS");
        intent.putExtra("branch_force_new_session", true);

        Button button = (Button)findViewById(R.id.deeplink_test_button);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //new BranchEvent("go_main_act").logEvent(PlayerDetailActivity.this);

                BranchUniversalObject item1 = new BranchUniversalObject()
                        .setContentMetadata(
                                new ContentMetadata()
                                        .setProductBrand("ARITAUM")
                                        .setProductName("유니크 매직 벨벳 필터 틴트")
                                        .setSku("15358123")
                                        .setPrice(9500.0, CurrencyType.KRW)
                                        .setQuantity(2.0)
                                        .addCustomMetadata("product_category", "메이크업/립/립틴트")
                                        .addCustomMetadata("option", "1호 유니크 로즈")
                        );
                BranchUniversalObject item2 = new BranchUniversalObject()
                        .setContentMetadata(
                                new ContentMetadata()
                                        .setProductBrand("ARITAUM")
                                        .setProductName("유니크 매직 벨벳 필터 틴트")
                                        .setSku("15358123")
                                        .setPrice(9500.0, CurrencyType.KRW)
                                        .setQuantity(2.0)
                                        .addCustomMetadata("product_category", "메이크업/립/립틴트")
                                        .addCustomMetadata("option", "1호 유니크 로즈")
                        );
                ArrayList<BranchUniversalObject> contentItems = new ArrayList<BranchUniversalObject> ();
                contentItems.add(item1);
                contentItems.add(item2);
                BranchEvent event = new BranchEvent(BRANCH_STANDARD_EVENT.ADD_TO_CART);
                event.addContentItems(contentItems);
                event.logEvent(PlayerDetailActivity.this);


                new BranchEvent("user_registration").logEvent(PlayerDetailActivity.this);


                startActivity(intent);
            }
        });


   /*
        BranchUniversalObject item1 = new BranchUniversalObject()
                .setContentMetadata(
                        new ContentMetadata()
                                .setProductBrand("My Brand")
                                .setProductName("My Product Name")
                                .setSku("My Product ID")
                                .setPrice(3000.0, CurrencyType.KRW)
                                .setQuantity(3.0)
                                .addCustomMetadata("product_category", "My Category")
                                .addCustomMetadata("option1", "red")
                                .addCustomMetadata("option2", "10ml")
                );

       new BranchEvent("Registration").logEvent(this);
       */


    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.i("Branch-SDK", "PlayerDetailActivity started");

    }
}
